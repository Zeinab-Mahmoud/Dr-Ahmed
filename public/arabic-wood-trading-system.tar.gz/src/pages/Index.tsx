import { useState } from 'react';
import Sidebar from '@/components/Sidebar';
import InvoiceForm from '@/components/InvoiceForm';
import Footer from '@/components/Footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Package,
  FileText,
  Users,
  BarChart3,
  Calendar
} from 'lucide-react';

export default function Index() {
  const [activeSection, setActiveSection] = useState('new-invoice');
  const [showInvoiceForm, setShowInvoiceForm] = useState(false);
  const [invoiceType, setInvoiceType] = useState<'وارد' | 'منصرف'>('وارد');

  const handleNewInvoice = (type: 'وارد' | 'منصرف') => {
    setInvoiceType(type);
    setShowInvoiceForm(true);
  };

  const renderContent = () => {
    if (showInvoiceForm) {
      return (
        <InvoiceForm 
          type={invoiceType} 
          onClose={() => setShowInvoiceForm(false)} 
        />
      );
    }

    switch (activeSection) {
      case 'new-invoice':
        return (
          <div className="p-6 space-y-6">
            {/* Header Section */}
            <div className="text-center space-y-4">
              <h1 className="text-4xl font-bold text-blue-800 mb-2">
                مرحباً بك في شركة العامر لتجارة الأخشاب
              </h1>
              <p className="text-lg text-muted-foreground">
                نظام إدارة شامل للمخزون والفواتير والعملاء
              </p>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-green-600">إجمالي المبيعات</p>
                      <p className="text-2xl font-bold text-green-800">0 جنيه</p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-blue-600">إجمالي المشتريات</p>
                      <p className="text-2xl font-bold text-blue-800">0 جنيه</p>
                    </div>
                    <TrendingDown className="h-8 w-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-purple-600">صافي الربح</p>
                      <p className="text-2xl font-bold text-purple-800">0 جنيه</p>
                    </div>
                    <DollarSign className="h-8 w-8 text-purple-600" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-orange-600">عدد العملاء</p>
                      <p className="text-2xl font-bold text-orange-800">0</p>
                    </div>
                    <Users className="h-8 w-8 text-orange-600" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* New Invoice Section */}
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-right flex items-center justify-end gap-2">
                <FileText className="h-6 w-6" />
                إضافة فاتورة جديدة
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="cursor-pointer hover:shadow-xl transition-all duration-300 transform hover:scale-105 bg-gradient-to-br from-green-50 to-green-100 border-green-200 hover:border-green-300" 
                      onClick={() => handleNewInvoice('وارد')}>
                  <CardHeader className="text-center">
                    <div className="mx-auto w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mb-4">
                      <TrendingDown className="h-8 w-8 text-white" />
                    </div>
                    <CardTitle className="text-right text-green-700 text-xl">فاتورة وارد</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-right text-muted-foreground mb-4">
                      إضافة فاتورة شراء جديدة من المورد
                    </p>
                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                      مشتريات
                    </Badge>
                  </CardContent>
                </Card>
                
                <Card className="cursor-pointer hover:shadow-xl transition-all duration-300 transform hover:scale-105 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200 hover:border-blue-300"
                      onClick={() => handleNewInvoice('منصرف')}>
                  <CardHeader className="text-center">
                    <div className="mx-auto w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mb-4">
                      <TrendingUp className="h-8 w-8 text-white" />
                    </div>
                    <CardTitle className="text-right text-blue-700 text-xl">فاتورة منصرف</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-right text-muted-foreground mb-4">
                      إضافة فاتورة بيع جديدة للعميل
                    </p>
                    <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                      مبيعات
                    </Badge>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="text-right flex items-center justify-end gap-2">
                  <BarChart3 className="h-5 w-5" />
                  النشاط الأخير
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">لا يوجد نشاط حتى الآن</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    ابدأ بإضافة فاتورة جديدة لرؤية النشاط هنا
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'incoming':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right mb-6 flex items-center justify-end gap-2">
              <TrendingDown className="h-6 w-6 text-green-600" />
              فواتير الوارد
            </h2>
            <Card className="border-green-200">
              <CardContent className="p-8">
                <div className="text-center">
                  <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-lg font-medium text-muted-foreground mb-2">
                    لا توجد فواتير وارد حتى الآن
                  </p>
                  <p className="text-sm text-muted-foreground mb-4">
                    ابدأ بإضافة فاتورة وارد جديدة لتتبع مشترياتك
                  </p>
                  <Button onClick={() => handleNewInvoice('وارد')} className="bg-green-600 hover:bg-green-700">
                    إضافة فاتورة وارد
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'outgoing':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right mb-6 flex items-center justify-end gap-2">
              <TrendingUp className="h-6 w-6 text-blue-600" />
              فواتير المنصرف
            </h2>
            <Card className="border-blue-200">
              <CardContent className="p-8">
                <div className="text-center">
                  <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-lg font-medium text-muted-foreground mb-2">
                    لا توجد فواتير منصرف حتى الآن
                  </p>
                  <p className="text-sm text-muted-foreground mb-4">
                    ابدأ بإضافة فاتورة منصرف جديدة لتتبع مبيعاتك
                  </p>
                  <Button onClick={() => handleNewInvoice('منصرف')} className="bg-blue-600 hover:bg-blue-700">
                    إضافة فاتورة منصرف
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'debt':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right mb-6 flex items-center justify-end gap-2">
              <DollarSign className="h-6 w-6 text-red-600" />
              الديون
            </h2>
            <Card className="border-red-200">
              <CardContent className="p-8">
                <div className="text-center">
                  <DollarSign className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-lg font-medium text-muted-foreground mb-2">
                    لا توجد ديون مسجلة حتى الآن
                  </p>
                  <p className="text-sm text-muted-foreground">
                    سيتم عرض الديون المستحقة هنا عند إضافة فواتير غير مدفوعة
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'credit':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right mb-6 flex items-center justify-end gap-2">
              <DollarSign className="h-6 w-6 text-orange-600" />
              المدان
            </h2>
            <Card className="border-orange-200">
              <CardContent className="p-8">
                <div className="text-center">
                  <DollarSign className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-lg font-medium text-muted-foreground mb-2">
                    لا توجد مديونيات مسجلة حتى الآن
                  </p>
                  <p className="text-sm text-muted-foreground">
                    سيتم عرض المديونيات هنا عند وجود مبالغ مستحقة للعملاء
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'inventory':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right mb-6 flex items-center justify-end gap-2">
              <Package className="h-6 w-6 text-purple-600" />
              المخزن
            </h2>
            <Card className="border-purple-200">
              <CardContent className="p-8">
                <div className="text-center">
                  <Package className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-lg font-medium text-muted-foreground mb-2">
                    المخزن فارغ حالياً
                  </p>
                  <p className="text-sm text-muted-foreground">
                    سيتم تحديث المخزن تلقائياً عند إضافة فواتير الوارد والمنصرف
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'customers':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right mb-6 flex items-center justify-end gap-2">
              <Users className="h-6 w-6 text-indigo-600" />
              العملاء
            </h2>
            <Card className="border-indigo-200">
              <CardContent className="p-8">
                <div className="text-center">
                  <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-lg font-medium text-muted-foreground mb-2">
                    لا يوجد عملاء مسجلين حتى الآن
                  </p>
                  <p className="text-sm text-muted-foreground">
                    سيتم إضافة العملاء تلقائياً عند إنشاء فواتير جديدة
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        );
      
      default:
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right">مرحباً بك في شركة العامر لتجارة الأخشاب</h2>
          </div>
        );
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-gray-50 to-blue-50" dir="rtl">
      <div className="flex flex-1">
        <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
        <main className="flex-1 overflow-auto">
          {renderContent()}
        </main>
      </div>
      <Footer />
    </div>
  );
}