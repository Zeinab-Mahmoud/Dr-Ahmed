import { Invoice, InventoryItem, Customer, DebtRecord, AppSettings } from '@/types';

const STORAGE_KEYS = {
  INVOICES: 'wood_company_invoices',
  INVENTORY: 'wood_company_inventory',
  CUSTOMERS: 'wood_company_customers',
  DEBTS: 'wood_company_debts',
  SETTINGS: 'wood_company_settings',
};

// Generic storage functions
export const saveToStorage = <T>(key: string, data: T[]): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving to localStorage:', error);
  }
};

export const loadFromStorage = <T>(key: string): T[] => {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error loading from localStorage:', error);
    return [];
  }
};

// Invoice functions
export const saveInvoices = (invoices: Invoice[]): void => {
  saveToStorage(STORAGE_KEYS.INVOICES, invoices);
};

export const loadInvoices = (): Invoice[] => {
  return loadFromStorage<Invoice>(STORAGE_KEYS.INVOICES);
};

export const addInvoice = (invoice: Invoice): void => {
  const invoices = loadInvoices();
  invoices.push(invoice);
  saveInvoices(invoices);
};

// Inventory functions
export const saveInventory = (inventory: InventoryItem[]): void => {
  saveToStorage(STORAGE_KEYS.INVENTORY, inventory);
};

export const loadInventory = (): InventoryItem[] => {
  return loadFromStorage<InventoryItem>(STORAGE_KEYS.INVENTORY);
};

export const updateInventoryStock = (itemId: string, quantityChange: number): void => {
  const inventory = loadInventory();
  const itemIndex = inventory.findIndex(item => item.id === itemId);
  if (itemIndex !== -1) {
    inventory[itemIndex].الكمية_المتاحة += quantityChange;
    saveInventory(inventory);
  }
};

// Customer functions
export const saveCustomers = (customers: Customer[]): void => {
  saveToStorage(STORAGE_KEYS.CUSTOMERS, customers);
};

export const loadCustomers = (): Customer[] => {
  return loadFromStorage<Customer>(STORAGE_KEYS.CUSTOMERS);
};

export const addOrUpdateCustomer = (customer: Customer): void => {
  const customers = loadCustomers();
  const existingIndex = customers.findIndex(c => c.id === customer.id);
  
  if (existingIndex !== -1) {
    customers[existingIndex] = customer;
  } else {
    customers.push(customer);
  }
  
  saveCustomers(customers);
};

// Debt functions
export const saveDebts = (debts: DebtRecord[]): void => {
  saveToStorage(STORAGE_KEYS.DEBTS, debts);
};

export const loadDebts = (): DebtRecord[] => {
  return loadFromStorage<DebtRecord>(STORAGE_KEYS.DEBTS);
};

export const addDebtRecord = (debt: DebtRecord): void => {
  const debts = loadDebts();
  debts.push(debt);
  saveDebts(debts);
};

// Settings functions
export const saveSettings = (settings: AppSettings): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (error) {
    console.error('Error saving settings:', error);
  }
};

export const loadSettings = (): AppSettings => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return data ? JSON.parse(data) : {
      عرض_السعر_المعدل: true,
      الأعمدة_المخفية: [],
      العملة: 'جنيه'
    };
  } catch (error) {
    console.error('Error loading settings:', error);
    return {
      عرض_السعر_المعدل: true,
      الأعمدة_المخفية: [],
      العملة: 'جنيه'
    };
  }
};

// Utility functions
export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('ar-EG', {
    style: 'currency',
    currency: 'EGP',
    minimumFractionDigits: 2
  }).format(amount);
};

export const getCurrentDateTime = (): { date: string; time: string } => {
  const now = new Date();
  return {
    date: now.toLocaleDateString('ar-EG'),
    time: now.toLocaleTimeString('ar-EG', { hour12: false })
  };
};