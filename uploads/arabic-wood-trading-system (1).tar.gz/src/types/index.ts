export interface InvoiceItemDetail {
  id: string;
  العرض: number;
  التخانة: number;
  الطول: number;
  السعر: number;
  المكعب: number;
  الإجمالي: number;
}

export interface InvoiceItem {
  id: string;
  العدد_الإجمالي: number;
  النوع: string;
  البيان: string;
  التفاصيل: InvoiceItemDetail[];
  إجمالي_الصنف: number;
  السعر_المعدل?: {
    فصال?: number;
    سعر_المتر_بعد_الفصال?: number;
    مديونية?: number;
    الفرق?: number;
  };
}

export interface Invoice {
  id: string;
  رقم_الفاتورة: string;
  التاريخ: string;
  الوقت: string;
  اسم_العميل: string;
  رقم_الهاتف?: string;
  نوع_الفاتورة: 'وارد' | 'منصرف';
  العناصر: InvoiceItem[];
  مصاريف_النقل?: number;
  مصاريف_التنزيل?: number;
  إجمالي_المصاريف: number;
  الإجمالي_النهائي: number;
  حالة_الدفع: 'مدفوع' | 'غير مدفوع' | 'مدفوع جزئياً';
  المبلغ_المدفوع?: number;
  المبلغ_المتبقي?: number;
  ملاحظات?: string;
}

export interface Customer {
  id: string;
  الاسم: string;
  رقم_الهاتف?: string;
  العنوان?: string;
  تاريخ_الإضافة: string;
  إجمالي_المشتريات: number;
  إجمالي_المبيعات: number;
  الرصيد_الحالي: number;
}

export interface InventoryItem {
  id: string;
  النوع: string;
  البيان: string;
  الكمية_المتاحة: number;
  الوحدة: string;
  السعر_الأساسي: number;
  تاريخ_آخر_تحديث: string;
}

export interface DebtRecord {
  id: string;
  اسم_العميل: string;
  نوع_المعاملة: 'دين' | 'مدان';
  المبلغ: number;
  التاريخ: string;
  الوصف?: string;
  حالة_السداد: 'مسدد' | 'غير مسدد' | 'مسدد جزئياً';
  المبلغ_المسدد?: number;
  المبلغ_المتبقي?: number;
}

export interface Settings {
  عرض_السعر_المعدل: boolean;
  العملة_الافتراضية: string;
  ضريبة_القيمة_المضافة: number;
}