import { useState } from 'react';
import Sidebar from '@/components/Sidebar';
import InvoiceForm from '@/components/InvoiceForm';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function Index() {
  const [activeSection, setActiveSection] = useState('new-invoice');
  const [showInvoiceForm, setShowInvoiceForm] = useState(false);
  const [invoiceType, setInvoiceType] = useState<'وارد' | 'منصرف'>('وارد');

  const handleNewInvoice = (type: 'وارد' | 'منصرف') => {
    setInvoiceType(type);
    setShowInvoiceForm(true);
  };

  const renderContent = () => {
    if (showInvoiceForm) {
      return (
        <InvoiceForm 
          type={invoiceType} 
          onClose={() => setShowInvoiceForm(false)} 
        />
      );
    }

    switch (activeSection) {
      case 'new-invoice':
        return (
          <div className="p-6 space-y-6">
            <h2 className="text-2xl font-bold text-right">إضافة فاتورة جديدة</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="cursor-pointer hover:shadow-lg transition-shadow" 
                    onClick={() => handleNewInvoice('وارد')}>
                <CardHeader>
                  <CardTitle className="text-right text-green-600">فاتورة وارد</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-right text-muted-foreground">
                    إضافة فاتورة شراء جديدة من المورد
                  </p>
                </CardContent>
              </Card>
              
              <Card className="cursor-pointer hover:shadow-lg transition-shadow"
                    onClick={() => handleNewInvoice('منصرف')}>
                <CardHeader>
                  <CardTitle className="text-right text-blue-600">فاتورة منصرف</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-right text-muted-foreground">
                    إضافة فاتورة بيع جديدة للعميل
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        );
      
      case 'incoming':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right mb-6">فواتير الوارد</h2>
            <Card>
              <CardContent className="p-6">
                <p className="text-center text-muted-foreground">
                  لا توجد فواتير وارد حتى الآن
                </p>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'outgoing':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right mb-6">فواتير المنصرف</h2>
            <Card>
              <CardContent className="p-6">
                <p className="text-center text-muted-foreground">
                  لا توجد فواتير منصرف حتى الآن
                </p>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'debt':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right mb-6">الديون</h2>
            <Card>
              <CardContent className="p-6">
                <p className="text-center text-muted-foreground">
                  لا توجد ديون مسجلة حتى الآن
                </p>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'credit':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right mb-6">المدان</h2>
            <Card>
              <CardContent className="p-6">
                <p className="text-center text-muted-foreground">
                  لا توجد مديونيات مسجلة حتى الآن
                </p>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'inventory':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right mb-6">المخزن</h2>
            <Card>
              <CardContent className="p-6">
                <p className="text-center text-muted-foreground">
                  المخزن فارغ حالياً
                </p>
              </CardContent>
            </Card>
          </div>
        );
      
      case 'customers':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right mb-6">العملاء</h2>
            <Card>
              <CardContent className="p-6">
                <p className="text-center text-muted-foreground">
                  لا يوجد عملاء مسجلين حتى الآن
                </p>
              </CardContent>
            </Card>
          </div>
        );
      
      default:
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-right">مرحباً بك في شركة العامر لتجارة الأخشاب</h2>
          </div>
        );
    }
  };

  return (
    <div className="flex min-h-screen bg-background" dir="rtl">
      <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      <main className="flex-1 overflow-auto">
        {renderContent()}
      </main>
    </div>
  );
}