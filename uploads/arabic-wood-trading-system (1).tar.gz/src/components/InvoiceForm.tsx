import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Switch } from '@/components/ui/switch';
import { Trash2, Plus } from 'lucide-react';
import { Invoice, InvoiceItem, InvoiceItemDetail } from '@/types';
import { generateId, getCurrentDateTime, addInvoice } from '@/lib/storage';

interface InvoiceFormProps {
  type: 'وارد' | 'منصرف';
  onClose: () => void;
}

export default function InvoiceForm({ type, onClose }: InvoiceFormProps) {
  const [invoice, setInvoice] = useState<Partial<Invoice>>({
    نوع_الفاتورة: type,
    العناصر: [],
    مصاريف_النقل: 0,
    مصاريف_التنزيل: 0,
    إجمالي_المصاريف: 0,
    الإجمالي_النهائي: 0,
    حالة_الدفع: 'مدفوع'
  });

  const [showAdjustedPrice, setShowAdjustedPrice] = useState(false);

  useEffect(() => {
    const { date, time } = getCurrentDateTime();
    setInvoice(prev => ({
      ...prev,
      التاريخ: date,
      الوقت: time,
      رقم_الفاتورة: `${type}-${Date.now()}`
    }));
  }, [type]);

  const addNewRow = () => {
    const newDetail: InvoiceItemDetail = {
      id: generateId(),
      العرض: 0,
      التخانة: 0,
      الطول: 0,
      السعر: 0,
      المكعب: 0,
      الإجمالي: 0
    };

    const newItem: InvoiceItem = {
      id: generateId(),
      العدد_الإجمالي: 1,
      النوع: '',
      البيان: '',
      التفاصيل: [newDetail],
      إجمالي_الصنف: 0
    };

    setInvoice(prev => ({
      ...prev,
      العناصر: [...(prev.العناصر || []), newItem]
    }));
  };

  const updateItemField = (itemId: string, field: keyof InvoiceItem, value: string | number) => {
    setInvoice(prev => ({
      ...prev,
      العناصر: prev.العناصر?.map(item => {
        if (item.id === itemId) {
          const updatedItem = { ...item, [field]: value };
          // Recalculate item total
          updatedItem.إجمالي_الصنف = updatedItem.التفاصيل.reduce((sum, detail) => sum + detail.الإجمالي, 0);
          return updatedItem;
        }
        return item;
      })
    }));
  };

  const updateDetailField = (itemId: string, field: keyof InvoiceItemDetail, value: number) => {
    setInvoice(prev => ({
      ...prev,
      العناصر: prev.العناصر?.map(item => {
        if (item.id === itemId) {
          const updatedItem = {
            ...item,
            التفاصيل: item.التفاصيل.map(detail => {
              const updatedDetail = { ...detail, [field]: value };
              
              // Calculate المكعب automatically
              if (['العرض', 'التخانة', 'الطول'].includes(field)) {
                updatedDetail.المكعب = updatedDetail.العرض * updatedDetail.التخانة * updatedDetail.الطول;
              }
              
              // Calculate الإجمالي automatically
              if (['المكعب', 'السعر'].includes(field) || ['العرض', 'التخانة', 'الطول'].includes(field)) {
                updatedDetail.الإجمالي = updatedDetail.المكعب * updatedDetail.السعر * item.العدد_الإجمالي;
              }

              return updatedDetail;
            })
          };
          
          // Recalculate item total
          updatedItem.إجمالي_الصنف = updatedItem.التفاصيل.reduce((sum, detail) => sum + detail.الإجمالي, 0);
          return updatedItem;
        }
        return item;
      })
    }));
  };

  const removeRow = (itemId: string) => {
    setInvoice(prev => ({
      ...prev,
      العناصر: prev.العناصر?.filter(item => item.id !== itemId)
    }));
  };

  const calculateTotals = () => {
    const itemsTotal = invoice.العناصر?.reduce((sum, item) => sum + item.إجمالي_الصنف, 0) || 0;
    const expensesTotal = (invoice.مصاريف_النقل || 0) + (invoice.مصاريف_التنزيل || 0);
    
    setInvoice(prev => ({
      ...prev,
      إجمالي_المصاريف: expensesTotal,
      الإجمالي_النهائي: type === 'وارد' ? itemsTotal + expensesTotal : itemsTotal
    }));
  };

  useEffect(() => {
    calculateTotals();
  }, [invoice.العناصر, invoice.مصاريف_النقل, invoice.مصاريف_التنزيل]);

  const handleSubmit = () => {
    if (!invoice.اسم_العميل || !invoice.العناصر?.length) {
      alert('يرجى ملء جميع البيانات المطلوبة');
      return;
    }

    const completeInvoice: Invoice = {
      id: generateId(),
      رقم_الفاتورة: invoice.رقم_الفاتورة!,
      التاريخ: invoice.التاريخ!,
      الوقت: invoice.الوقت!,
      اسم_العميل: invoice.اسم_العميل!,
      رقم_الهاتف: invoice.رقم_الهاتف || '',
      نوع_الفاتورة: type,
      العناصر: invoice.العناصر!,
      مصاريف_النقل: invoice.مصاريف_النقل,
      مصاريف_التنزيل: invoice.مصاريف_التنزيل,
      إجمالي_المصاريف: invoice.إجمالي_المصاريف!,
      الإجمالي_النهائي: invoice.الإجمالي_النهائي!,
      حالة_الدفع: invoice.حالة_الدفع!,
      المبلغ_المدفوع: invoice.المبلغ_المدفوع,
      المبلغ_المتبقي: invoice.المبلغ_المتبقي
    };

    addInvoice(completeInvoice);
    alert('تم حفظ الفاتورة بنجاح');
    onClose();
  };

  return (
    <div className="max-w-full mx-auto p-4 space-y-4 bg-white">
      {/* Header matching Excel style */}
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold text-blue-800 mb-2">شركة العامر لتجارة الأخشاب</h1>
        <h2 className="text-xl font-semibold text-gray-700">فاتورة {type}</h2>
      </div>

      {/* Invoice Info */}
      <div className="grid grid-cols-3 gap-4 mb-6 p-4 bg-gray-50 rounded">
        <div>
          <Label className="text-sm font-bold">رقم الفاتورة:</Label>
          <Input
            value={invoice.رقم_الفاتورة || ''}
            onChange={(e) => setInvoice(prev => ({ ...prev, رقم_الفاتورة: e.target.value }))}
            className="text-right mt-1"
          />
        </div>
        <div>
          <Label className="text-sm font-bold">التاريخ:</Label>
          <Input
            value={invoice.التاريخ || ''}
            readOnly
            className="text-right mt-1 bg-white"
          />
        </div>
        <div>
          <Label className="text-sm font-bold">الوقت:</Label>
          <Input
            value={invoice.الوقت || ''}
            readOnly
            className="text-right mt-1 bg-white"
          />
        </div>
      </div>

      {/* Customer Info */}
      <div className="grid grid-cols-2 gap-4 mb-6 p-4 bg-gray-50 rounded">
        <div>
          <Label className="text-sm font-bold">اسم العميل:</Label>
          <Input
            value={invoice.اسم_العميل || ''}
            onChange={(e) => setInvoice(prev => ({ ...prev, اسم_العميل: e.target.value }))}
            className="text-right mt-1"
            placeholder="أدخل اسم العميل"
          />
        </div>
        <div>
          <Label className="text-sm font-bold">رقم الهاتف:</Label>
          <Input
            value={invoice.رقم_الهاتف || ''}
            onChange={(e) => setInvoice(prev => ({ ...prev, رقم_الهاتف: e.target.value }))}
            className="text-right mt-1"
            placeholder="أدخل رقم الهاتف"
          />
        </div>
      </div>

      {/* Toggle for adjusted price columns */}
      <div className="flex items-center justify-end gap-2 mb-4">
        <Label htmlFor="show-adjusted-price" className="text-sm font-bold">عرض السعر المعدل:</Label>
        <Switch
          id="show-adjusted-price"
          checked={showAdjustedPrice}
          onCheckedChange={setShowAdjustedPrice}
        />
      </div>

      {/* Excel-like Table - Reordered columns as requested */}
      <div className="border-2 border-black rounded-lg overflow-hidden">
        {/* Add Item Button */}
        <div className="p-2 bg-blue-100 border-b border-black">
          <Button onClick={addNewRow} size="sm" className="bg-green-600 hover:bg-green-700">
            <Plus className="h-4 w-4 ml-2" />
            إضافة صف
          </Button>
        </div>

        <div className="overflow-x-auto">
          <Table className="w-full border-collapse">
            <TableHeader>
              <TableRow className="bg-blue-200 border-b-2 border-black">
                {/* Column 1: عدد الامتار الإجمالي */}
                <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[100px]">عدد الامتار الإجمالي</TableHead>
                {/* Column 2: النوع */}
                <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[80px]">النوع</TableHead>
                {/* Column 3: البيان */}
                <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[120px]">البيان</TableHead>
                {/* Column 4: العرض */}
                <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[80px]">العرض (م)</TableHead>
                {/* Column 5: التخانة */}
                <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[80px]">التخانة (م)</TableHead>
                {/* Column 6: الطول */}
                <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[80px]">الطول (م)</TableHead>
                {/* Column 7: سعر المتر */}
                <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[100px]">سعر المتر (جنيه)</TableHead>
                {/* Column 8: المكعب */}
                <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[80px]">المكعب (م³)</TableHead>
                {/* Column 9: السعر */}
                <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[100px]">السعر (جنيه)</TableHead>
                {/* Column 10: الإجمالي */}
                <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[100px]">الإجمالي (جنيه)</TableHead>
                {/* Adjusted Price Columns (Optional) */}
                {showAdjustedPrice && (
                  <>
                    <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[100px] bg-yellow-200">فصال (جنيه)</TableHead>
                    <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[120px] bg-yellow-200">سعر المتر بعد الفصال (جنيه)</TableHead>
                    <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[100px] bg-yellow-200">مديونية (جنيه)</TableHead>
                    <TableHead className="border-r border-black text-center font-bold text-black p-2 min-w-[80px] bg-yellow-200">الفرق (جنيه)</TableHead>
                  </>
                )}
                {/* Delete Column */}
                <TableHead className="text-center font-bold text-black p-2 min-w-[60px]">حذف</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {invoice.العناصر?.map((item, index) => (
                <TableRow key={item.id} className={`border-b border-gray-300 ${index % 2 === 0 ? "bg-white" : "bg-gray-50"}`}>
                  {/* Column 1: عدد الامتار الإجمالي */}
                  <TableCell className="border-r border-gray-300 p-1">
                    <Input
                      type="number"
                      value={item.العدد_الإجمالي}
                      onChange={(e) => updateItemField(item.id, 'العدد_الإجمالي', Number(e.target.value))}
                      className="w-full text-center text-sm border-0 p-1"
                      min="1"
                    />
                  </TableCell>
                  {/* Column 2: النوع */}
                  <TableCell className="border-r border-gray-300 p-1">
                    <Input
                      value={item.النوع}
                      onChange={(e) => updateItemField(item.id, 'النوع', e.target.value)}
                      className="w-full text-center text-sm border-0 p-1"
                      placeholder="النوع"
                    />
                  </TableCell>
                  {/* Column 3: البيان */}
                  <TableCell className="border-r border-gray-300 p-1">
                    <Input
                      value={item.البيان}
                      onChange={(e) => updateItemField(item.id, 'البيان', e.target.value)}
                      className="w-full text-center text-sm border-0 p-1"
                      placeholder="البيان"
                    />
                  </TableCell>
                  {/* Column 4: العرض */}
                  <TableCell className="border-r border-gray-300 p-1">
                    <Input
                      type="number"
                      step="0.01"
                      value={item.التفاصيل[0]?.العرض || 0}
                      onChange={(e) => updateDetailField(item.id, 'العرض', Number(e.target.value))}
                      className="w-full text-center text-sm border-0 p-1"
                      min="0"
                    />
                  </TableCell>
                  {/* Column 5: التخانة */}
                  <TableCell className="border-r border-gray-300 p-1">
                    <Input
                      type="number"
                      step="0.01"
                      value={item.التفاصيل[0]?.التخانة || 0}
                      onChange={(e) => updateDetailField(item.id, 'التخانة', Number(e.target.value))}
                      className="w-full text-center text-sm border-0 p-1"
                      min="0"
                    />
                  </TableCell>
                  {/* Column 6: الطول */}
                  <TableCell className="border-r border-gray-300 p-1">
                    <Input
                      type="number"
                      step="0.01"
                      value={item.التفاصيل[0]?.الطول || 0}
                      onChange={(e) => updateDetailField(item.id, 'الطول', Number(e.target.value))}
                      className="w-full text-center text-sm border-0 p-1"
                      min="0"
                    />
                  </TableCell>
                  {/* Column 7: سعر المتر */}
                  <TableCell className="border-r border-gray-300 p-1">
                    <Input
                      type="number"
                      step="0.01"
                      value={0}
                      className="w-full text-center text-sm border-0 p-1"
                      min="0"
                      placeholder="سعر المتر"
                    />
                  </TableCell>
                  {/* Column 8: المكعب */}
                  <TableCell className="text-center font-bold border-r border-gray-300 bg-blue-100 p-2">
                    {item.التفاصيل[0]?.المكعب.toFixed(3) || '0.000'}
                  </TableCell>
                  {/* Column 9: السعر */}
                  <TableCell className="border-r border-gray-300 p-1">
                    <Input
                      type="number"
                      step="0.01"
                      value={item.التفاصيل[0]?.السعر || 0}
                      onChange={(e) => updateDetailField(item.id, 'السعر', Number(e.target.value))}
                      className="w-full text-center text-sm border-0 p-1"
                      min="0"
                    />
                  </TableCell>
                  {/* Column 10: الإجمالي */}
                  <TableCell className="text-center font-bold border-r border-gray-300 bg-green-100 p-2">
                    {item.التفاصيل[0]?.الإجمالي.toFixed(2) || '0.00'}
                  </TableCell>
                  {/* Adjusted Price Columns (Optional) */}
                  {showAdjustedPrice && (
                    <>
                      <TableCell className="border-r border-gray-300 bg-yellow-100 p-1">
                        <Input
                          type="number"
                          step="0.01"
                          value={item.السعر_المعدل?.فصال || 0}
                          onChange={(e) => updateItemField(item.id, 'السعر_المعدل', {
                            ...item.السعر_المعدل,
                            فصال: Number(e.target.value)
                          })}
                          className="w-full text-center text-sm border-0 p-1"
                          min="0"
                        />
                      </TableCell>
                      <TableCell className="border-r border-gray-300 bg-yellow-100 p-1">
                        <Input
                          type="number"
                          step="0.01"
                          value={item.السعر_المعدل?.سعر_المتر_بعد_الفصال || 0}
                          onChange={(e) => updateItemField(item.id, 'السعر_المعدل', {
                            ...item.السعر_المعدل,
                            سعر_المتر_بعد_الفصال: Number(e.target.value)
                          })}
                          className="w-full text-center text-sm border-0 p-1"
                          min="0"
                        />
                      </TableCell>
                      <TableCell className="border-r border-gray-300 bg-yellow-100 p-1">
                        <Input
                          type="number"
                          step="0.01"
                          value={item.السعر_المعدل?.مديونية || 0}
                          onChange={(e) => updateItemField(item.id, 'السعر_المعدل', {
                            ...item.السعر_المعدل,
                            مديونية: Number(e.target.value)
                          })}
                          className="w-full text-center text-sm border-0 p-1"
                          min="0"
                        />
                      </TableCell>
                      <TableCell className="border-r border-gray-300 bg-yellow-100 p-1">
                        <Input
                          type="number"
                          step="0.01"
                          value={item.السعر_المعدل?.الفرق || 0}
                          onChange={(e) => updateItemField(item.id, 'السعر_المعدل', {
                            ...item.السعر_المعدل,
                            الفرق: Number(e.target.value)
                          })}
                          className="w-full text-center text-sm border-0 p-1"
                        />
                      </TableCell>
                    </>
                  )}
                  {/* Delete Column */}
                  <TableCell className="text-center p-1">
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => removeRow(item.id)}
                      className="h-6 w-6 p-0"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {invoice.العناصر?.length === 0 && (
                <TableRow>
                  <TableCell colSpan={showAdjustedPrice ? 15 : 11} className="text-center py-8 text-gray-500 border-r border-gray-300">
                    اضغط على "إضافة صف" لبدء إدخال البيانات
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Additional Expenses for وارد invoices */}
      {type === 'وارد' && (
        <Card className="mt-4">
          <CardHeader className="bg-orange-100">
            <CardTitle className="text-right text-orange-800">المصاريف الإضافية</CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-bold">مصاريف النقل:</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={invoice.مصاريف_النقل || 0}
                  onChange={(e) => setInvoice(prev => ({ ...prev, مصاريف_النقل: Number(e.target.value) }))}
                  className="text-right mt-1"
                  min="0"
                />
              </div>
              <div>
                <Label className="text-sm font-bold">مصاريف التنزيل:</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={invoice.مصاريف_التنزيل || 0}
                  onChange={(e) => setInvoice(prev => ({ ...prev, مصاريف_التنزيل: Number(e.target.value) }))}
                  className="text-right mt-1"
                  min="0"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Summary */}
      <div className="bg-gray-100 p-4 rounded-lg border-2 border-gray-300">
        <div className="text-right space-y-2">
          <div className="text-lg">
            <span className="font-bold">إجمالي الأصناف: </span>
            <span className="text-blue-600 font-bold">
              {(invoice.العناصر?.reduce((sum, item) => sum + item.إجمالي_الصنف, 0) || 0).toFixed(2)} جنيه
            </span>
          </div>
          {type === 'وارد' && (
            <div className="text-lg">
              <span className="font-bold">إجمالي المصاريف: </span>
              <span className="text-orange-600 font-bold">
                {(invoice.إجمالي_المصاريف || 0).toFixed(2)} جنيه
              </span>
            </div>
          )}
          <div className="text-xl border-t-2 border-gray-400 pt-2">
            <span className="font-bold">الإجمالي النهائي: </span>
            <span className="text-green-600 font-bold text-2xl">
              {(invoice.الإجمالي_النهائي || 0).toFixed(2)} جنيه
            </span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-between items-center pt-4">
        <div className="space-x-4">
          <Button variant="outline" onClick={onClose} size="lg">
            إلغاء
          </Button>
          <Button onClick={handleSubmit} size="lg" className="bg-green-600 hover:bg-green-700">
            حفظ الفاتورة
          </Button>
        </div>
      </div>
    </div>
  );
}