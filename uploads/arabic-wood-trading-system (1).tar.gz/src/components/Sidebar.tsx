import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { 
  FileText, 
  Package, 
  TrendingDown, 
  CreditCard, 
  Users, 
  Warehouse,
  Plus
} from 'lucide-react';

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

export default function Sidebar({ activeSection, onSectionChange }: SidebarProps) {
  const menuItems = [
    { id: 'new-invoice', label: 'إضافة فاتورة جديدة', icon: Plus },
    { id: 'incoming', label: 'وارد', icon: TrendingDown },
    { id: 'outgoing', label: 'منصرف', icon: FileText },
    { id: 'debt', label: 'دين', icon: CreditCard },
    { id: 'credit', label: 'مدان', icon: CreditCard },
    { id: 'inventory', label: 'مخزن', icon: Warehouse },
    { id: 'customers', label: 'عملاء', icon: Users },
  ];

  return (
    <Card className="w-64 h-screen p-4 rounded-none border-l-0 border-t-0 border-b-0">
      <div className="mb-8 text-center">
        <h1 className="text-xl font-bold text-primary mb-2">
          شركة العامر
        </h1>
        <p className="text-sm text-muted-foreground">
          لتجارة الأخشاب
        </p>
      </div>

      <nav className="space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <Button
              key={item.id}
              variant={activeSection === item.id ? 'default' : 'ghost'}
              className="w-full justify-start text-right h-12"
              onClick={() => onSectionChange(item.id)}
            >
              <Icon className="ml-2 h-4 w-4" />
              {item.label}
            </Button>
          );
        })}
      </nav>

      <div className="mt-8 p-4 bg-muted rounded-lg">
        <h3 className="font-semibold text-sm mb-2">الإحصائيات السريعة</h3>
        <div className="space-y-1 text-xs">
          <div className="flex justify-between">
            <span>إجمالي المشتريات:</span>
            <span className="font-semibold">0 جنيه</span>
          </div>
          <div className="flex justify-between">
            <span>إجمالي المبيعات:</span>
            <span className="font-semibold">0 جنيه</span>
          </div>
          <div className="flex justify-between">
            <span>صافي الربح:</span>
            <span className="font-semibold text-green-600">0 جنيه</span>
          </div>
        </div>
      </div>
    </Card>
  );
}